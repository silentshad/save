package com.a2944100.reversi;

/**
 * Created by silentshad on 20/03/17.
 */

/**
 * class representing the discs used in the game
 */
class Discs {

    int color;

    /**
     * Constructor setting the color to -1 which represent a discs which no color discs owned by
     * Constructor setting the color to -1 which represent a discs which no color discs owned by
     * a player will have has color the number of the player
     */
    Discs(){
        color = -1;
    }
}
